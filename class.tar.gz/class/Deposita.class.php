<?php

    class Deposita{
        private $idusuario;
        private $idPosto_coleta;
        private $idmaterial;
        private $qtd;
        
               
        function __construct($_idusuario=null,$_idPosto_coleta=null,$_idmaterial=null,$_qtd=null){
            
            $this->idusuario= $_idusuario;
            $this->idPosto_coleta= $_idPosto_coleta;
            $this->idmaterial=$_idmaterial;
            $this->qtd= $_qtd;
            

                      
        }
        function getIdusuario(){
            return $this->idusuario;
        }
        function setIdusuario($_idusuario){
            $this->idusuario=$_idusuario;
        }
        function getIdPosto_coleta(){
            return $this->idPosto_coleta;
        }
        
        function setIdPosto_coleta($_idPosto_coleta){
            $this->idPosto_coleta=$_idPosto_coleta;
        }
        
        function getIdmaterial(){
            return $this->idmaterial;
        }
        function setIdmaterial($_idmaterial){
            $this->idmaterial= $_idmaterial;
        }
        
        function getQtd(){
            return $this->qtd;
        }
        function setQtd($_qtd){
         $this->qtd=$_qtd;
        }
        
        function deposito($idusuario,$idposto,$idmaterial,$quanti,$mysqli){
            $query= "insert into Deposita Values" . "($idusuario,$idposto,$idmaterial,$quanti)";
             $mysqli->query($query);
            if($mysqli->affected_rows==1){
                
                $id=$mysqli->insert_id;
                return $id;
            }else{
                return false;
            }
            $quer1="Select qtd from Estoque_Posto_coleta where idPosto_coleta=$id and idmaterial=$idmaterial";
            $resultado=$mysqli->query($query);
            $linha=$resultado->fetch_array();
            $quantidade=$linha['qtd'];
            $total=$quanti+$quantidade;
            $sql="Update Estoque_Posto_coleta set qtd=$total where idPosto_coleta=$idposto";
             $mysqli->query($query);
            if($mysqli->affected_rows==1){
                return true;
            }else{
                return false;
            }

        }
        function raking($mysqli,$idusuario){
            $query="Select Usuario.idUsuario,Usuario.nome,sum(Deposita.qtd) as 'total' from Usuario inner join Deposita on (Usuario.idUsuario==Deposita.idUsuario) group by Usuario.nome";
            $resultado= $mysqli->query($query);
            while($linha = $resultado->fetch_array()){
                if($linha[idUsuario]==$idusuario){
                echo "Nome:". $linha['nome'] ." Quantidade Dados:". $linha['total'] . "</br>";

            }else{
                echo "Nome:". $linha['nome'] ." Quantidade Dados:". $linha['total'] . "</br>";
            }

        }
    }
    
?>